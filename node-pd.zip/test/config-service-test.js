"use strict";

import "babel-polyfill";

import { expect } from "chai";
import sinon from "sinon";
import configService from "../src/config-service.js";
import fs from "fs";
import path from "path";

describe("Config service",  () => {
	describe("#purge()",  () => {
		before(() => {
			sinon.spy(fs, "writeFileSync");
		});

		after(() => {
			fs.writeFileSync.restore();
		});

		it("should remove everything from the config",  () => {
			configService.purge();

			expect(fs.writeFileSync.calledOnce);
			expect(fs.writeFileSync.getCall(0).args[1]).to.be.empty;
		});
	});
	
	describe("#load()",  () => { 
		it("should load configs",  () => {
			const savedConfig = {
				username: "the user name"
			};
			const stub = sinon.stub(fs, "readFileSync", () => {
				return JSON.stringify(savedConfig); 
			});

			const result = configService.load(); 

			expect(result).to.eql(savedConfig);

			stub.restore();
		});

		it("should return empty if file invalid", () => {
			const stub = sinon.stub(fs, "readFileSync", () => {
				throw "File does not exists."
			});

			const result = configService.load();

			expect(result).to.equal(null);

			stub.restore();
		});
	});
}); 