"use strict";

import "babel-polyfill";

import { expect } from "chai";
import sinon from "sinon";
import fs from "fs";
import path from "path";
import CONST from "../src/constants.js"
import pdService from "../src/pd-service.js"

describe("PD service",  () => {
	describe("#getCooldownSeconds()",  () => {
		before(() => {
			sinon.stub(Math, "random", function () {
				return 0.618;
			});
		});

		after(() => {
			Math.random.restore();
		});

		it("should return the specified duration.",  () => {
			let r = pdService.getCooldownSeconds(10, 10);
			expect(r).equal(10);
		});

		it("should return correct value in Normal mode.",  () => {
			let r = pdService.getCooldownSeconds(CONST.cooldownStrategies.NORMAL, 10);
			expect(r).equal(CONST.cooldownSeconds[CONST.cooldownStrategies.NORMAL] + 1);
		});

		it("should return correct value in Prudent mode.",  () => {
			let r = pdService.getCooldownSeconds(CONST.cooldownStrategies.PRUDENT, 10);
			expect(r).equal(CONST.cooldownSeconds[CONST.cooldownStrategies.PRUDENT] + 1);
		});

		it("should return correct value in Auto mode (T1).",  () => {
			let r = pdService.getCooldownSeconds(CONST.cooldownStrategies.AUTO, 30);
			expect(r).equal(31);
		});

		it("should return correct value in Auto mode (T2).",  () => {
			let r = pdService.getCooldownSeconds(CONST.cooldownStrategies.AUTO, 90);
			expect(r).equal(49);
		});

		it("should return correct value in Auto mode (T3).",  () => {
			let r = pdService.getCooldownSeconds(CONST.cooldownStrategies.AUTO, 241);
			expect(r).equal(121);
		});

		it("should return correct value in Auto mode (T2 when duration not provided).",  () => {
			let r = pdService.getCooldownSeconds(CONST.cooldownStrategies.AUTO, undefined);
			expect(r).equal(31);
		});
	});
});