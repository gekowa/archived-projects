"use strict";

/**
 * download command
 */
import path from "path";
import fs from "fs";
import http from "http";
import colors from "colors/safe";
import moment from "moment";
import sanitizeFilename from "sanitize-filename";
import { init as progressTrack } from "../progress-track.js";
import { run } from "../run.js";
import CONST from "../constants.js";
import PDService from "../pd-service";
import configService from "../config-service.js";

export const execute = (argv) => {
	let username = argv.user || configService.get("username"),
		password = argv.pass || configService.get("password"),
		savePath = argv.path || configService.get("path"),
		cooldown = argv.cooldown || configService.get("cooldown");
	
	if (!username || !password) {
		console.error("Error: [user] and [pass] are required.");
		process.exit(9); 	// invalid arguments
	}

	if (!savePath) {
		console.error("Error: [path] is required.");
		process.exit(9); 	// invalid arguments
	}

	if (cooldown === null || typeof cooldown === "undefined") {
		cooldown = CONST.cooldownStrategies.AUTO;
	}

	const courseIds = argv._.slice(1);

	if (courseIds.length === 0) {
		// no course to download? why here?
		console.log("No course to download, exiting...");
		process.exit(0);
	}

	run(function *main() {
		const pd = new PDService(username, password);

		// login
		try {
			console.log(`Logging in with ${username}...`);
			if (yield pd.login()) {
				if (yield pd.getSubscription()) {
					// check subscription
					if (pd.isExpired) {
						console.log(colors.red(`Failed! Your subscription is expired. Exiting...`));
						process.exit(9);
					}
					console.log(colors.green(`Success! Subscription type is [${pd.subscriptionType}].`));
				} else {
					console.log(colors.red(`Failed! Your subscription is invalid. Exiting...`));
					process.exit(9);
				}
			} else {
				console.log(colors.red(`Authentication failed. Exiting...`));
				process.exit(9);
			}
		} catch (e) {
			// login failed
			if (typeof e === "number") {
				// status code
				let statusMessage = http.STATUS_CODES[e];
				console.error(colors.red(`Failed (${statusMessage})`));
			}
			process.exit(9);
			return;
		}

		// loop over courses		
		for (let i = 0; i < courseIds.length; i++) {
			console.log(`Downloading: ${i + 1} of ${courseIds.length} course(s).`);

			let courseId = courseIds[i];

			console.log(`Loading course: [${courseId}]`);

			let courseInfo;

			try {
				courseInfo = yield pd.getCourseInfo(courseId);
			} catch (e) {
				if (typeof e === "number") {
					// status code
					let statusMessage = http.STATUS_CODES[e];
					console.log(colors.red(`Failed to load course data. ${statusMessage})`));
				} else {
					console.log(colors.red(`Failed to load course data. ${e.message})`));
				}
				
				continue;
			}

			if (!courseInfo) {
				console.log(colors.red("Loading course data error."));
				continue;
			}

			let courseTitle = courseInfo.title;
			console.log(colors.white(`Course: ${courseTitle} `));

			// create save folder
			let properFolderName = path.join(savePath, sanitizeFilename(courseTitle, { replacement: "_"}));
			try {
				fs.mkdirSync(properFolderName);
			} catch (e) {
				if (e.code !== "EEXIST") {
					// error but not because of already exist
					console.log(colors.red("Creating folder error!"));
					continue;
				}
			}

			// save courseInfo json
			fs.writeFileSync(path.join(properFolderName, "info.json"), JSON.stringify(courseInfo));

			// get transcript
			let transcript;
			try {
				transcript = yield pd.getTranscript(courseId);
			} catch (e) {
				console.log(colors.yellow("Failed to load transcript."));
			}
			fs.writeFileSync(path.join(properFolderName, "transcript.json"), JSON.stringify(transcript));

			// progress track
			let progressTracker = progressTrack(properFolderName);

			for (let j = 0; j < courseInfo.modules.length; j++) {
				let theModule = courseInfo.modules[j],
					moduleTitle = theModule.title,
					clips = theModule.clips,
					moduleTranscript;

				if (transcript) {
					moduleTranscript = transcript.modules[j];
				}

				console.log(colors.yellow(`Module: ${moduleTitle}`));

				for (let k = 0; k < clips.length; k++) {
					let clip = clips[k],
						clipTitle = clip.title,
						clipName = clip.name;

					console.log(colors.yellow(`|--Clip: ${clipTitle}`));

					if (moduleTranscript) {
						const clipTranscripts = moduleTranscript.clipTranscripts[k];
						let subtitleFilename = sanitizeFilename(`${j + 1}-${k + 1}-${moduleTitle}-${clipTitle}.srt`, { replacement: "_"});
						if (clipTranscripts && clipTranscripts.transcripts && clipTranscripts.transcripts.length > 0) {
							const srtContent = clipTranscripts.transcripts.map(function (t, tIndex) {
								const startTime = moment.utc(t.relativeStartTime).format("HH:mm:ss,SSS"),
									endTime = moment.utc(t.relativeEndTime).format("HH:mm:ss,SSS");
								return `${tIndex + 1}
${startTime} --> ${endTime}
${t.text}\n\n`;
						}).join("");
							fs.writeFileSync(path.join(properFolderName, subtitleFilename), srtContent);
						}
					}

					// check if already downloaded
					if (progressTracker.isDone(clipName)) {
						console.log(colors.green("Already downloaded."));
						continue;
					}

					let videoURL;
					try {
						videoURL = yield pd.getVideoURL(courseId, theModule, clip);

						// only download if we got the URL
						try {
							// download
							let fileName = sanitizeFilename(`${j + 1}-${k + 1}-${moduleTitle}-${clipTitle}.mp4`, { replacement: "_"});
							yield pd.downloadVideo(videoURL, path.join(properFolderName, fileName));

							progressTracker.setDone(clipName);

						} catch (e) {
							console.error("Download error.");
							continue;
						}
						
						// TODO: verify downloaded file
					}
					catch (e) {
						console.error(`Get video URL error. ${e}`);
						continue;
					}

					// wait and countdown
					yield pd.waitAndCountdown(cooldown, clip.durationInMilliseconds / 1000);
				}
			}
		}		
	}).then(
		// fullfiled
		function () {
			process.exit(0);
		},
		// rejected
		function (err) {
			console.error(err);
		}
	);
}