"use strict";

/**
 * Config command
 */

import _ from "lodash";
import CONST from "../constants.js";
import configService from "../config-service.js";
import path from "path";

export const execute = (argv) => {
	let objectToSave = {};
	if (argv.user) {
		Object.assign(objectToSave, {
			username: argv.user
		});
	} 

	if (argv.pass) {
		Object.assign(objectToSave, {
			password: argv.pass
		});
	} 

	if (argv.path) {
		const savePath = path.resolve(argv.path);
		Object.assign(objectToSave, {
			path: savePath
		});
	}

	if (argv.cooldown) {
		if (typeof argv.cooldown === "number" || _.values(CONST.cooldownStrategies).indexOf(argv.cooldown) >= 0) {
			Object.assign(objectToSave, {
				cooldown: argv.cooldown
			});
		}
	} 

	if (_.isEmpty(objectToSave)) {
		// load and display
		const loaded = configService.load();
		if (loaded) {
			if (loaded.hasOwnProperty("password")) {
				loaded["password"] = "******";
			}
			console.log(JSON.stringify(loaded, null, 2));
		}
	} else {
		configService.set(objectToSave);
	}
}