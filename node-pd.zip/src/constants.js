module.exports = {
	cooldownStrategies: {
		AUTO: "Auto",
		NORMAL: "Normal",
		PRUDENT: "Prudent"
	},

	cooldownSeconds: {
		"Normal": 45,
		"Prudent": 60
	}
}