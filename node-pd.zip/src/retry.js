"use strict";

export function retry(func, retryCount, successCb, failCb, errors) {
	func(
		function (result) {
			// console.log(result);
			successCb(result);
		},
		function (e) {
			errors = errors || [];
			errors.push(e);
			if (retryCount > 1) {
				// console.log("Retry: " + retryCount);
				setTimeout(function () {
					retry(func, retryCount -  1, successCb, failCb, errors);
				}, 5000);
			} else {
				failCb(errors);
			}
		}
	);
}