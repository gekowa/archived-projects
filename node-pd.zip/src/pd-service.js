"use strict";

import fs from "fs";
import request from "request";
import ansi from "ansi";
import colors from "colors/safe";
import uuid from "uuid";
import {
	retry
} from "./retry.js";
import CONST from "./constants.js";
// import decimalAdjust from "./decimal-adjust.js"),

const cursor = ansi(process.stdout);

const API_BASE = "https://app.pluralsight.com/mobile-api/v1/";
// for playback
// const USER_AGENT = "AppleCoreMedia/1.0.0.13E238 (iPhone; U; CPU OS 9_3_1 like Mac OS X; en_us)";
// for offline download
const USER_AGENT = "pluralsight/792 CFNetwork/808.1.4 Darwin/16.1.0";
// const VIDEO_PLAY_INTERVAL = 40; // seconds

const RETRY_WAIT = 5; // seconds
const RETRY_COUNT = 3;

export default class PDService {
	constructor(username, password) {
		this.username = username;
		this.password = password;

		this.baseRequest = request.defaults({
			headers: {
				"user-agent": USER_AGENT
			}
		});
	}

	login() {
		var url = API_BASE + "/user/signin",
			credentials = {
				"username": this.username,
				"password": this.password
			};

		var p = new Promise((resolve, reject) => {
			this.baseRequest.post(url, {
					"form": credentials
				},
				(error, response, body) => {
					if (!error && response.statusCode === 200) {
						// console.log(body);
						this.tokenInfo = JSON.parse(body);

						// also add token to header
						this.tokenizedRequest = this.baseRequest.defaults({
							"headers": {
								"ps-jwt": this.tokenInfo.token
							}
						})

						resolve(this.tokenInfo.authenticated);
					} else {
						if (error) {
							reject(error);
						} else {
							reject(response.statusCode);
						}
					}
				}
			);
		});

		return p;
	}

	getSubscription() {
		var url = API_BASE + "/user/subscription";

		var p = new Promise((resolve, reject) => {
			this.tokenizedRequest.get(url,
				(error, response, body) => {
					if (!error && response.statusCode === 200) {
						const subscriptionInfo = JSON.parse(body);

						Object.assign(this, subscriptionInfo.librarySubscription);

						resolve(!!(subscriptionInfo.librarySubscription));
					} else {
						if (error) {
							reject(error);
						} else {
							reject(response.statusCode);
						}
					}
				}
			);
		});

		return p;
	}

	getCourseInfo(courseId) {
		var url = API_BASE + "/library/courses/" + courseId;

		var p = new Promise((resolve, reject) => {
			retry((success, fail) => {
				request(url,
					(error, response, body) => {
						if (!error && response.statusCode === 200) {
							success(JSON.parse(body));
						} else {
							if (error) {
								fail(error);
							} else {
								fail(response.statusCode);
							}
						}
					});

			}, RETRY_COUNT, resolve, reject);
		});

		return p;
	}

	getVideoURL(courseId, moduleInfo, clipInfo) {
		const payload = {
			"author": moduleInfo.authorHandle,
			"moduleindexposition": clipInfo.index,
			"module": moduleInfo.name,
			"format": clipInfo.supportsWideScreen ? "1280x720mp4" : "1024x768mp4",
			"course": courseId
		};

		let url = API_BASE +
			(/plus/i.test(this.subscriptionType) ? "/library/videos/offline" : "/library/videos");

		var p = new Promise((resolve, reject) => {
			retry((success, fail) => {
				// added "offline", wondering if only "plus" subscription has this feature
				this.tokenizedRequest.post(url, {
						"form": payload
					},
					(error, response, body) => {
						if (!error && response.statusCode === 200) {
							success(JSON.parse(body).url);
						} else {
							if (error) {
								fail(error);
							} else {
								fail(response.statusCode);
							}
						}
					});
			}, RETRY_COUNT, resolve, reject);
		});

		return p;
	}

	getTranscript(courseId) {
		var p = new Promise((resolve, reject) => {
			retry((success, fail) => {
				this.tokenizedRequest.get(API_BASE + "/library/coursetranscripts/" + courseId + "/en",
					(error, response, body) => {
						if (!error && response.statusCode === 200) {
							success(JSON.parse(body));
						} else {
							if (error) {
								fail(error);
							} else {
								fail(response.statusCode);
							}
						}
					});
			}, RETRY_COUNT, resolve, reject);
		});

		return p;
	}

	downloadVideo(url, savePath) {
		var playbackSessionId = uuid.v1();

		return new Promise((resolve, reject) => {
			retry((success, fail) => {
				this.baseRequest(url, {
						"headers": {
							"X-Playback-Session-Id": playbackSessionId,
							"Range": "bytes=0-1"
						}
					}, (error, resp) => {
						if (resp.headers["x-amz-version-id"]) {
							let contentRange = resp.headers["content-range"];
							let length = parseInt(contentRange.match(/\/(\d+)$/)[1]);
							success(length);
						} else {
							fail("Missing critical response header: x-amz-version-id");
						}
					})
					.on("error", (e) => {
						fail(e);
					});
			}, RETRY_COUNT, resolve, reject);
		}).then((contentLength) => {
			return new Promise((resolve, reject) => {
				var bytesCounter = 0;
				retry((success, fail) => {
					this.baseRequest(url, {
							"headers": {
								"X-Playback-Session-Id": playbackSessionId,
								"Range": `bytes=0-${contentLength - 1}`
							}
						})
						.on("error", (e) => {
							fail(e);
						})
						.on("finish", () => {
							cursor.horizontalAbsolute(0).eraseLine().write(colors.green("Done.\r\n"));
							success();
						})
						.on("data", (chunk) => {
							bytesCounter += chunk.length;
							var progress = Math.round(bytesCounter * 100 / contentLength);
							cursor.horizontalAbsolute(0).eraseLine().write(`Downloading ${progress}%`);
						})
						.pipe(fs.createWriteStream(savePath));
				}, RETRY_COUNT, resolve, reject);
			});
		});
	}

	getCooldownSeconds(strategy, duration) {
		if (typeof strategy === "number") {
			// TODO: display
			return strategy;
		}
		switch (strategy) {
			case CONST.cooldownStrategies.AUTO:
				if (typeof duration === "undefined") {
					duration = 0;
				}
				if (duration < 60) {
					return Math.round(30 + 10 * (Math.random() - 0.5));
				} else if (duration >= 60 && duration <= 4 * 60) {
					return Math.round(duration / 3 + Math.random() * duration / 3);
				} else if (duration > 4 * 60) {
					return Math.round(120 + 10 * (Math.random() - 0.5));
				}
				break;
			case CONST.cooldownStrategies.NORMAL:
				return Math.round(CONST.cooldownSeconds[strategy] + 10 * (Math.random() - 0.5));
			case CONST.cooldownStrategies.PRUDENT:
				return Math.round(CONST.cooldownSeconds[strategy] + 10 * (Math.random() - 0.5));
		}
	}

	waitAndCountdown(strategy, duration) {
		return new Promise((resolve) => {
			let secondsToWait = this.getCooldownSeconds(strategy, duration),
				countdown = setInterval(() => {
					cursor.horizontalAbsolute(0).eraseLine().write(`Waiting ${Math.round(secondsToWait)}s`);
					if (secondsToWait <= 0) {
						clearInterval(countdown);
						cursor.horizontalAbsolute(0).eraseLine();
						resolve();
					}
					secondsToWait -= 1;
				}, 1000);
		});
	}
}