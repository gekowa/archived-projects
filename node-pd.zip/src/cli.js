"use strict";

/**
 * pd <command> options
 */

import pkg from "../../package.json";
import yargs from "yargs";

const CONFIG_COMMAND = "config",
	DOWNLOAD_COMMAND = "download";

const argv = yargs.usage(`Pluralsight Downloader ${pkg.version}\n
Usage: pd <command> [options]`)
	.command(CONFIG_COMMAND, "Config parameters used for downloading from Pluralsight.")
	.command(DOWNLOAD_COMMAND, "Download course video from Pluralsight.")
	.alias("u", "user")
	.alias("p", "pass")
	.alias("s", "path")
	.alias("d", "cooldown")
	.describe("u", "Use the username")
	.describe("p", "Use the password")
	.describe("s", "Save to path")
	.describe("d", `Cooldown time, seconds to wait after a video is downloaded. Can be 'Normal'(about 45s), 'Prudent'(about 60s), 'Auto' or any number you want. Default to 'Auto'`)
	.argv;

let command = argv._[0];
 
switch (command) {
	case CONFIG_COMMAND:
	case DOWNLOAD_COMMAND:
		require(`./commands/${command}`).execute(argv);
		break;
	default: 
		yargs.showHelp();
		process.exit(0);
		break;
}