"use strict";

const
  path = require("path"),
  fs = require("fs"),
  _ = require("lodash"),

  CONFIG_FILE = path.join(process.env[(process.platform == "win32") ? "USERPROFILE" : "HOME"], "/.pdrc"),
  PROPERTIES = ["username", "password", "path", "cooldown"];

module.exports = {
  load() {
    try {
      const loaded = fs.readFileSync(CONFIG_FILE),
          parsed = JSON.parse(loaded);
      return parsed;
    } catch (e) {
      return null;
    }
  },
  set(cfg) {
    const toSave = _.assign(this.load() || {}, _.pick(cfg, PROPERTIES));
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(toSave));
  },
  get(key) {
    const loaded = this.load();
    if (loaded) {
      return loaded[key];
    }
    return null;
  },
  purge() {
    fs.writeFileSync(CONFIG_FILE, "");
  }
};