"use strict";

import path from "path";
import fs from "fs";

const PROGRESS_FILE = ".progress",
	__proto = {
		isDone: function (id)	{
			try {
				var progressPath = path.join(this.basePath, PROGRESS_FILE),
					fileContent = fs.readFileSync(progressPath).toString();

				return new RegExp("^" + id + "$", "mi").test(fileContent);
			} catch (e) {
				if (e.code === "ENOENT") {
					// do nothing
					return false;
				}
			}
		},
		setDone: function (id) {
			var progressPath = path.join(this.basePath, PROGRESS_FILE);
			fs.appendFileSync(progressPath, id + "\r\n");
		}
	};

export const init = (basePath) => {
	const tracker = Object.create(__proto);
	tracker.basePath = basePath;

	return tracker;
}