# node-pd
A utility that helps you download video of [Pluralsight](http://pluralsight.com) to your local disk.

## Feature
- (new) Downloads transcript and convert to SRT subtitle file for each video file
- (new) Stores user/pass and path so that no need to key in while downloading
- Remembers the progress of downloading
- Wait for seconds (cooldown) after each clip downloads, prevent your account from being disabled

## Note
Using this tool requires you to have your own valid subscription to [Pluralsight](http://pluralsight.com)

## Usage

```
npm install -g node-pd
pd download -u [account] -p [password] -s [path-to-save] [list of course id separated by space char]
```

Or configure before downloading.

```
pd config -u [account] -p [password] -s [path-to-save]
pd download [list of course id separated by space char] 
```

## How to find course id
E.g., if URL of a course page is "https://www.pluralsight.com/courses/react-redux-react-router-es6", the course id is "react-redux-react-router-es6".

## Examples
```
pd download react-redux-react-router-es6 play-by-play-nano-server
```
This will download both "Building Applications with React and Redux in ES6" and "Play by Play: Nano Server".

## Customize cooldown time
To prevent Pluralsight from blocking your account, we need to wait for dozens of seconds between downloads. 

There're 3 modes: Auto, Normal, Prudent. The default mode is Auto, in which the interval is calculated based on video duration.

```
pd config -d [Auto|Normal|Prudent]
```

Here Normal is around 45 seconds, Prudent is around 60 seconds.

You can also specify a static number of seconds. E.g.,

```
pd config -d 4
```

The program will wait for 4 seconds after each download.

## Warning
Using this tool might violate the [Terms of Use](https://www.pluralsight.com/terms) of Pluralsight, use at your own risk.
