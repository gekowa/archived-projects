const D2UConverter = require("@raider/dos2unix").dos2unix;
const path = require("path");

console.log("build.js starts.");

Promise.resolve().then(() => {
	// fix line ending of bin/pd 
	const d2u = new D2UConverter({ glob: { cwd: path.join(__dirname, "../bin/.")}})
		.on("error", function(err) {
			console.error(err);
		})
		.on("end", function(stats) {
			console.log(stats);
		});

	d2u.process("pd");
});
